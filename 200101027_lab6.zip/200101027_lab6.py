import os

path = "C:/Users/cchan/Downloads/database-07-mar-2022/database-07-mar-2022/course-wise-students-list"

os.chdir(path)
counter=1

fo = open(path+"/output.csv", "a", encoding="utf8")
dir = os.listdir()
for i in dir:
    if(i=="output.csv"):
      continue
    os.chdir(path+"/"+i)
    files = os.listdir()

    for j in files:
        s = path + "/" +i+ "/" +j
        k = j.split(".")[0]
        
        f = open(s)
        count=0
        counter=counter-1
        while True:
            counter=counter+1
            count=str(counter)
            line = f.readline()
            if not line:
                break
            data=line.split(",")
            fo.write(count+","+k+","+data[1]+","+data[2]+","+data[3])
        f.close()