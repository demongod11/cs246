create database assignment08;
use assignment08;

create table ett(cid char(8), exam_date date, start_time time, end_time time);
create table cc(cid char(8) primary key, credits int);
create table cwsl(serial_number int,cid char(8),roll_number char(20),name char(50),email char(50),primary key(serial_number, cid));

load data local infile "C:/Users/cchan/Downloads/database-07-mar-2022/database-07-mar-2022/exam-time-table.csv" into table ett fields terminated by ',' lines terminated by '\n';
load data local infile "C:/Users/cchan/Downloads/database-07-mar-2022/database-07-mar-2022/course-credits.csv" into table cc fields terminated by ',' lines terminated by '\n';

-- Run 200101027_lab6.py before continuing with the rest of the sql code

load data local infile "C:/Users/cchan/Downloads/database-07-mar-2022/database-07-mar-2022/course-wise-students-list/output.csv" into table cwsl CHARACTER SET utf8mb4 fields terminated by ',' lines terminated by '\n';