delimiter //
create procedure count_credits()
begin
create table temp as (select * from cwsl natural join cc);
select * from (select roll_number, name, sum(credits) as random from temp group by roll_number) as random_again where random_again.random > 40 group by random_again.roll_number;
end; //
delimiter ;

call count_credits();