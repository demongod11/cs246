delimiter //
create procedure tt_violation()
begin
    create table temp_again as (select table1.roll_number, table1.name, table1.cid as cid1, table2.cid as cid2 from cwsl as table1 inner join cwsl as table2 on ((table1.roll_number = table2.roll_number) and (table1.name = table2.name) and (table1.cid != table2.cid)));
    select * from temp_again where exists
        (select * from 
            (ett as i inner join ett as j on (i.cid = cid1) and (j.cid = cid2) and (i.cid < j.cid))
                where (i.exam_date = j.exam_date) and
                (((i.start_time <= j.start_time) and (j.start_time <= i.end_time)) or ((j.start_time <= i.start_time) and (i.start_time <= j.end_time))));
end; //
delimiter ;
call tt_violation();